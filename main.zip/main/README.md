## O projekcie

Celem tego projektu jest stworzenie zestawu narzędzi do obsługi promocji czasowych przez firmy t.j. stacje benzynowe.

## Jak uruchomić aplikację

Tutaj przydałby się opis tego, jak uruchomić aplikację i co jest do tego potrzebne (np. wersja Javy).


```
mvn package
```
tworzy .jar

```
mvn javafx:run
```
po prostu odpala z kodu
