package app.service.control_panel.rewards;

public class CreateRewardService {
    // TODO: Implement business logic for creating rewards
}