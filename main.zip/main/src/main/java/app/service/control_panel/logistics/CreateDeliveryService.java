package app.service.control_panel.logistics;

public class CreateDeliveryService {
    // TODO: Implement business logic for creating deliveries
}