package app.service.control_panel.logistics;

public class CreateOutletService {
    // TODO: Implement business logic for creating outlets
}