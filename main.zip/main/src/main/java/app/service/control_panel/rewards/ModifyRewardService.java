package app.service.control_panel.rewards;

public class ModifyRewardService {
    // TODO: Implement business logic for modifying rewards
}