package app.service.control_panel.logistics;

public class ViewRequestsService {
    // TODO: Implement business logic for viewing requests
}