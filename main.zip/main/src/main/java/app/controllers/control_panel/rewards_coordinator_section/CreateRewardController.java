package app.controllers.control_panel.rewards_coordinator_section;

public class CreateRewardController {
    // TODO: Implement logic for creating rewards
}