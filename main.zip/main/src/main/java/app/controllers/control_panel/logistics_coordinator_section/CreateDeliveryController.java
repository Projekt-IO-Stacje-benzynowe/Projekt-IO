package app.controllers.control_panel.logistics_coordinator_section;

public class CreateDeliveryController {
    // TODO: Implement logic for creating deliveries
}