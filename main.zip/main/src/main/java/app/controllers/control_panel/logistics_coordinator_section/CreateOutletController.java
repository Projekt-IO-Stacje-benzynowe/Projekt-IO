package app.controllers.control_panel.logistics_coordinator_section;

public class CreateOutletController {
    // TODO: Implement logic for creating outlets
}