package app.controllers.control_panel.logistics_coordinator_section;

public class ViewRequestsController {
    // TODO: Implement logic for viewing requests
}