package app.controllers.control_panel.logistics_coordinator_section;

public class OutletController {
    // TODO: Implement logic for outlet overview
}