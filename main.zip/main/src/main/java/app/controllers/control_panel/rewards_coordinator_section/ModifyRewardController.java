package app.controllers.control_panel.rewards_coordinator_section;

public class ModifyRewardController {
    // TODO: Implement logic for modifying rewards
}