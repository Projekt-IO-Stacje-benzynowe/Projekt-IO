package app.controllers.branch_panel;

public class AcknowledgeReward {
    
}
