package app.controllers.business_panel;

public class ProductReport {
}
